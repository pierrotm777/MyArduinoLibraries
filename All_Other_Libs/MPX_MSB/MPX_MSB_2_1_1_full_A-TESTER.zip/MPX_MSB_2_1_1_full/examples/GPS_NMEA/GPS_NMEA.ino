
#include <MPX_MSB.h>
#include <TinyGPSPlus.h>
using namespace MPX;
Mpx_Msb mpx; TinyGPSPlus gps;
float batteryVoltage=15.0f, Celcius=25.0f, TempTank=30.0f;
static uint32_t lastFixMs = 0; static float lastAlt = 0.0f;
void setup(){
  mpx.begin(Serial3,38400);
  mpx.sendVbat(batteryVoltage); mpx.sendTmp1(Celcius); mpx.sendTmp2(TempTank);
  mpx.mapGpsAddrs(8,4,1); // Alt=8, Speed=4, Course=1
  mpx.mapVarioAddrs(8,2); // Alt=8 (same), VSpd=2
  Serial1.begin(9600);    // GPS NMEA
}
void loop(){
  while(Serial1.available()) gps.encode(Serial1.read());
  if(gps.location.isValid() && gps.date.isUpdated() && gps.time.isUpdated()){
    double lat=gps.location.lat(); double lon=gps.location.lng();
    float alt = gps.altitude.isValid()? gps.altitude.meters(): lastAlt;
    float spd = gps.speed.isValid()? gps.speed.mps(): 0.0f;
    float cog = gps.course.isValid()? gps.course.deg(): 0.0f;
    uint32_t now=millis(); float vspd=0.0f;
    if(lastFixMs){ float dt=(now-lastFixMs)/1000.0f; if(dt>0.001f) vspd=(alt-lastAlt)/dt; }
    lastFixMs=now; lastAlt=alt;
    mpx.Gps(lat,lon,alt,spd,cog,(uint8_t)(gps.date.year()-2000),(uint8_t)gps.date.month(),(uint8_t)gps.date.day(),
            (uint8_t)gps.time.hour(),(uint8_t)gps.time.minute(),(uint8_t)gps.time.second());
    mpx.Vario(alt,vspd);
  }
  mpx.sendVbat(batteryVoltage); mpx.sendTmp1(Celcius); mpx.sendTmp2(TempTank);
  mpx.poll();
}
