
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <MPX_MSB.h>
using namespace MPX;
Mpx_Msb mpx; Adafruit_BMP280 bmp;
float batteryVoltage=15.0f, temp2_demo=30.0f;
static uint32_t lastMs=0; static float lastAlt=0;
void setup(){
  mpx.begin(Serial3,38400); mpx.sendVbat(batteryVoltage);
  mpx.sendTmp1(25.0f); mpx.sendTmp2(temp2_demo);
  mpx.mapVarioAddrs(8,2);
  Wire.begin(); if(!bmp.begin(0x76)) bmp.begin(0x77);
  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
    Adafruit_BMP280::SAMPLING_X2,Adafruit_BMP280::SAMPLING_X16,
    Adafruit_BMP280::FILTER_X16,Adafruit_BMP280::STANDBY_MS_500);
  mpx.setIdleMicros(300); mpx.setEchoMasking(true);
}
void loop(){
  float tC=bmp.readTemperature(); float alt=bmp.readAltitude(1013.25);
  mpx.sendVbat(batteryVoltage); if(isfinite(tC)) mpx.sendTmp1(tC);
  float vspd=0; uint32_t now=millis();
  if(isfinite(alt)){ if(lastMs){ float dt=(now-lastMs)/1000.0f;
    if(dt>0.002f) vspd=(alt-lastAlt)/dt; } lastAlt=alt; lastMs=now; mpx.Vario(alt,vspd); }
  mpx.sendTmp2(temp2_demo); mpx.poll();
}
