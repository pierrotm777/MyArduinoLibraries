
#include <Wire.h>
#include <MPX_MSB.h>
#include <SparkFun_u-blox_GNSS_Arduino_Library.h>
using namespace MPX;
Mpx_Msb mpx; SFE_UBLOX_GNSS gnss;
float batteryVoltage=15.0f, Celcius=25.0f, TempTank=30.0f;
static uint32_t lastPvtMs=0; static long lastAltMSL=0;
void setup(){
  mpx.begin(Serial3,38400);
  mpx.sendVbat(batteryVoltage); mpx.sendTmp1(Celcius); mpx.sendTmp2(TempTank);
  mpx.mapGpsAddrs(8,4,1); mpx.mapVarioAddrs(8,2);
  Wire.begin();
  if(!gnss.begin()){ while(1); }
  gnss.setAutoPVT(true); gnss.setAutoVELNED(true);
}
void loop(){
  if(gnss.getPVT()){
    double lat = gnss.getLatitude()/1e7;
    double lon = gnss.getLongitude()/1e7;
    long altMSL = gnss.getAltitudeMSL(); float alt = altMSL/1000.0f;
    float spd_mps = (gnss.getGroundSpeed()/1000.0f);
    float cog = gnss.getHeading()/1e5;
    float vspd = 0.0f;
    if(gnss.getVELNED()) vspd = -(gnss.getDownSpeed()/1000.0f);
    else { uint32_t now=millis();
      if(lastPvtMs){ float dt=(now-lastPvtMs)/1000.0f; vspd=(alt - (lastAltMSL/1000.0f))/dt; }
      lastPvtMs=now; lastAltMSL=altMSL;
    }
    mpx.Gps(lat,lon,alt,spd_mps,cog,(uint8_t)(gnss.getYear()-2000),(uint8_t)gnss.getMonth(),(uint8_t)gnss.getDay(),
            (uint8_t)gnss.getHour(),(uint8_t)gnss.getMinute(),(uint8_t)gnss.getSecond());
    mpx.Vario(alt,vspd);
  }
  mpx.sendVbat(batteryVoltage); mpx.sendTmp1(Celcius); mpx.sendTmp2(TempTank);
  mpx.poll();
}
