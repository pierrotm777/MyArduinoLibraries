
# MPX_MSB

A lightweight library to emulate **Multiplex M‑LINK MSB sensors** from an Arduino/Teensy.
Created from the original MSRC work and adapted by ChatGPT for a simple poll→reply flow.

## Compatibility
- Arduino IDE 1.8.x / 2.x
- **Teensy 4.0** (tested), Arduino AVR should also work
- Multiplex receivers with **MLINK** telemetry (tested with **RX9DR**)

## Wiring
- Connect the **B/D (Data)** pin of the Multiplex receiver to your MCU TX (e.g. **Serial3** TX on Teensy 4.0).
- Recommended protection: **Option B (series diode + 1k)**.
- Share **GND** between receiver and MCU.
- B/D is an **input** on the receiver.

## Installation
- Copy this folder into your Arduino `libraries/` directory.
- Or use “Add .ZIP Library…” in the Arduino IDE.

## Usage (Quick Start)
```cpp
#include <MPX_MSB.h>
using namespace MPX;

Mpx_Msb mpx;

void setup(){
  mpx.begin(Serial3, 38400);

  // Basic sensors
  mpx.sendVbat(15.0f);  // addr 3 (0.1V)
  mpx.sendTmp1(25.0f);  // addr 6 (0.1°C)
  mpx.sendTmp2(30.0f);  // addr 7 (0.1°C)

  // Digital alarms (pullup, active LOW -> value 1 when LOW)
  // mpx.addAlarmDigital(18,  9);
  // mpx.addAlarmDigital(19, 10);
  // mpx.addAlarmDigital(22, 11);
  // mpx.addAlarmDigital(23, 12);
}

void loop(){
  // refresh dynamic values if needed:
  // mpx.sendVbat(batteryVoltage); mpx.sendTmp1(Celcius); mpx.sendTmp2(TempTank);
  mpx.poll();
}
```

## GPS sensor support
Use `Gps()` to provide GPS‑related data. Addresses can be mapped with `mapGpsAddrs(altAddr, spdAddr, cogAddr)`.
- **Altitude** → `MPX_HEIGHT` (1 m units)
- **Ground speed** → `MPX_SPEED` (0.1 km/h)
- **Course over ground** → `MPX_DIR` (0.1°)

Example (see `examples/GPS_NMEA/` and `examples/GPS_uBlox/`):
```cpp
mpx.mapGpsAddrs(/*alt*/8, /*spd*/4, /*cog*/1);
mpx.Gps(48.858289, 2.294502, 245.5, 100.0, 90.23, 24, 9, 14, 12, 0, 0);
```

## Vario sensor support
Use `Vario(alt_m, vspd_m_s)` to expose altitude and vertical speed.
Addresses can be mapped with `mapVarioAddrs(altAddr, vspdAddr)`.
- **Altitude** → `MPX_HEIGHT` (1 m)
- **Vertical speed** → `MPX_VSPEED` (0.1 m/s)

Example:
```cpp
mpx.mapVarioAddrs(/*alt*/8, /*vspd*/2);
mpx.Vario(250.5, -1.5);
```

## Examples
- `examples/BMP280_Vario` — altitude + vario from **Adafruit BMP280** (uses `STANDBY_MS_500` for wide compatibility)
- `examples/GPS_NMEA` — GPS via **TinyGPSPlus**
- `examples/GPS_uBlox` — GPS via **SparkFun u‑blox GNSS**

## Tested hardware
- **Multiplex RX‑9‑DR** receiver
- **Teensy 4.0** (Serial3 at 38400 baud)

## Credits
- Based on ideas from **MSRC** (Mstrens) project
- Adapted and extended with ChatGPT
