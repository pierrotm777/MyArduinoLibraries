
#include "MPX_MSB.h"
#include <math.h>
namespace MPX {

void Mpx_Msb::begin(HardwareSerial &ser, uint32_t baud){
  _ser = &ser; _ser->begin(baud); _daCount=0;
}

void Mpx_Msb::addAlarmDigital(uint8_t pin, uint8_t addr, uint8_t classId,
                              bool activeLow, bool usePullup,
                              float onValue, float offValue, float scale){
  if (_daCount >= MAX_DA) return;
  if (usePullup) pinMode(pin, INPUT_PULLUP); else pinMode(pin, INPUT);
  _da[_daCount++] = DAlarm{pin,(uint8_t)(addr&0x0F),classId,true,activeLow,onValue,offValue,scale};
}

uint16_t Mpx_Msb::encodeDeci(float deci, bool alarm){
  int v = (int)lroundf(deci);
  if (v < -16384) v = -16384; if (v > 16383) v = 16383;
  uint16_t u = ((uint16_t)(v<<1)) & 0xFFFE; if (alarm) u|=1; return u;
}

void Mpx_Msb::drainEcho(uint8_t n){
  if(!_ser || !_echoMask) return; uint32_t s=micros(); uint16_t d=0;
  while(d<n && (micros()-s)<1000){ if(_ser->read()>=0) d++; }
}

void Mpx_Msb::send3(uint8_t addr, uint8_t klass, uint16_t enc){
  if(!_ser) return; uint8_t b0=((addr&0x0F)<<4)|(klass&0x0F);
  uint8_t b1=(uint8_t)(enc&0xFF), b2=(uint8_t)((enc>>8)&0xFF);
  _ser->write(b0); _ser->write(b1); _ser->write(b2); drainEcho(3);
}

void Mpx_Msb::replyIfAsked(uint8_t a){
  if ((_addrV & 0x0F)==a){ send3(_addrV,MPX_VOLT,encodeDeci(vbat()*10.0f,false)); return; }
  if ((_addrT1 & 0x0F)==a){ send3(_addrT1,MPX_TMP,encodeDeci(t1()*10.0f,false)); return; }
  if ((_addrT2 & 0x0F)==a){ send3(_addrT2,MPX_TMP,encodeDeci(t2()*10.0f,false)); return; }
  if ((_addrAlt!=0xFF)&&((_addrAlt&0x0F)==a)){
    float alt = (_vario_alt_m!=0.0f)?_vario_alt_m:_gps_alt_m;
    send3(_addrAlt,MPX_HEIGHT,encodeDeci(alt*1.0f,false)); return; }
  if ((_addrVSpd!=0xFF)&&((_addrVSpd&0x0F)==a)){
    send3(_addrVSpd,MPX_VSPEED,encodeDeci(_vario_vspd_ms*10.0f,false)); return; }
  if ((_addrSpd!=0xFF)&&((_addrSpd&0x0F)==a)){
    send3(_addrSpd,MPX_SPEED,encodeDeci(_gps_spd_kmh*10.0f,false)); return; }
  if ((_addrCog!=0xFF)&&((_addrCog&0x0F)==a)){
    send3(_addrCog,MPX_DIR,encodeDeci(_gps_cog_deg*10.0f,false)); return; }
  for(uint8_t i=0;i<_daCount;i++){ const DAlarm &d=_da[i];
    if(!d.inUse||((d.addr&0x0F)!=a)) continue;
    int s=digitalRead(d.pin); bool active=d.activeLow?(s==LOW):(s==HIGH);
    float v=active?d.onValue:d.offValue;
    send3(d.addr,d.classId,encodeDeci(v*d.scale,active)); return; }
}

void Mpx_Msb::poll(){
  if(!_ser) return; while(_ser->available()){
    uint8_t poll=(uint8_t)_ser->read(); elapsedMicros em=0;
    while((uint32_t)em<_idleUs){} replyIfAsked((uint8_t)(poll&0x0F)); }
}

void Mpx_Msb::Gps(double, double, float alt_m, float speed_m_s, float course_deg,
                  uint8_t yy,uint8_t mm,uint8_t dd,uint8_t hh,uint8_t mi,uint8_t ss){
  _gps_alt_m=alt_m; _gps_spd_kmh=speed_m_s*3.6f;
  while(course_deg<0)course_deg+=360; while(course_deg>=360)course_deg-=360;
  _gps_cog_deg=course_deg; _gps_y=yy;_gps_mo=mm;_gps_d=dd;_gps_h=hh;_gps_min=mi;_gps_s=ss;
}

void Mpx_Msb::Vario(float alt_m,float vspd_m_s){ _vario_alt_m=alt_m; _vario_vspd_ms=vspd_m_s; }

void Mpx_Msb::mapGpsAddrs(uint8_t altAddr,uint8_t spdAddr,uint8_t cogAddr){
  _addrAlt=altAddr&0x0F; _addrSpd=spdAddr&0x0F; _addrCog=cogAddr&0x0F; }
void Mpx_Msb::mapVarioAddrs(uint8_t altAddr,uint8_t vspdAddr){
  _addrAlt=altAddr&0x0F; _addrVSpd=vspdAddr&0x0F; }

} // namespace MPX
